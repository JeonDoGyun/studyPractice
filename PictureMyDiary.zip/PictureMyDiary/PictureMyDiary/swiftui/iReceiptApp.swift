//
//  iReceiptApp.swift
//  iReceipt
//
//  Created by Federico on 26/01/2022.
//

import SwiftUI

@main
struct iReceiptApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView 
        }
    }
}
