//
//  PlaceSingleton.swift
//  trip
//
//  Created by 전도균 on 2023/02/22.
//

import Foundation
import UIKit
import CoreLocation

class PlaceSingleton {
    
    static let shared = PlaceSingleton()
    
    
    
    private init() {}
}
