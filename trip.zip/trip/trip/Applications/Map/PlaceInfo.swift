//
//  Singleton.swift
//  trip
//
//  Created by 전도균 on 2023/02/18.
//

import Foundation

class PlaceInfo {
    
    static let shared = PlaceInfo()
    
    private init() {}
}
