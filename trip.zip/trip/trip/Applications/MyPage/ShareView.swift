//
//  ShareView.swift
//  trip
//
//  Created by 전도균 on 2023/02/12.
//

import UIKit

class ShareView: UIView {
    
    override init(frame: CGRect) {
        super.init(frame: .zero)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

extension ShareView {
    private func setUI() {
        
    }
    
    private func setConstraints() {
        
    }
}
